// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract VendingMachine {
    address public owner;
    uint public donutBalance;

    constructor() {
        owner = msg.sender;
        donutBalance = 100;
    }

    function getVendingMachineBalance() public view returns (uint) {
        return donutBalance;
    }

    function restock(uint amount) public {
        require(msg.sender == owner, "Only owner can restock.");
        donutBalance += amount;
    }

    function purchase(uint amount) public payable {
        require(msg.value >= amount * 1e9, "Not enough ETH sent.");
        require(donutBalance >= amount, "Not enough donuts in stock.");
        donutBalance -= amount;
    }

    function refill(uint amount) public {
        require(msg.sender == owner, "Only owner can refill.");
        donutBalance += amount;
    }
}
